let app = require('./app/config/server');

let rotaHome = require('./app/routes/home');
rotaHome(app);

let rotaSobre = require('./app/routes/sobre');
rotaSobre(app);

let rotaProgramacao = require('./app/routes/programacao');
rotaProgramacao(app);

let rotaContato = require('./app/routes/contato');
rotaContato(app);

let rotaInscricao = require('./app/routes/inscricao');
rotaInscricao(app);

let rotaHistoria = require('./app/routes/historia');
rotaHistoria(app);

app.listen(3000, function() {
    console.log("Servidor iniciado na porta 3000");
});