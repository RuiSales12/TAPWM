module.exports = function(app) {
    app.get('/historia', function(req, res) {

        res.send(`
            <h1>História da Semana de Tecnologia</h1>

            <p>
                A Semana de Tecnologia foi criada com o objetivo de
                promover conhecimento, inovação e troca de experiências
                entre estudantes e profissionais da área de tecnologia.
            </p>

            <p>
                Ao longo de suas edições, o evento passou a reunir
                palestras e workshops relacionados ao desenvolvimento
                de sistemas, inteligência artificial, segurança da
                informação e outras áreas da tecnologia.
            </p>
        `);

    });
}